import { Link } from 'react'
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import '../node_modules/bootstrap/dist/js/bootstrap.min.js'


function App() {

  return (
    <>
    <h2>Welcome</h2>
    <br />
      <div className="row g-3 align-items-center">
        <div className="col-auto">
          <input type="name" id="name" className="form-control" aria-describedby="name" placeholder="Name" style={{ width: '100%' }} />
        </div>
      </div>
      <br />  
      <button type="button" className="btn btn-dark" >Login</button>    
    </>
    
  )
}

export default App
